
import Walkthroghsvg from '.././assets/images/walkthrough.svg'

import { Images } from "../assets/images";


export const ONBOARD_DATA = [
    {
        id: 1,

       image:Images.bigGift,
        ScreenName:"Explore PGs Effortlessly",
       
        body: "Discover thoughtful \n gifts for  every occasion \n with ease"
    },
    {
        id: 2,
       image:Images.bigGift,
        ScreenName:"Verified Listings & Hygiene First",
    
        body: "Browse, personalize, and \n send the perfect gift—all \n from your phone."
    },
    {
        id: 3,
    image:Images.bigGift,
        ScreenName:"Smart Search & Easy Booking",
  
        body: "Start exploring our \n collection and surprise \n someone special today",

    
      
    },
    
]
