export const img = {
  sample_1: require('../assets/images/Sample_1.png'),
};
