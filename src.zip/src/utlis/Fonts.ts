export const Fonts = {

  ralewayMedium: 'Raleway-Medium',
  ralewaySemiBold: 'Raleway-SemiBold',
  ralewayBold: 'Raleway-Bold',
  ralewayRegular: 'Raleway-Regular',
};