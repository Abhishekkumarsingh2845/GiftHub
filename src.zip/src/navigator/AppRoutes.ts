export enum AppRoutes{

    Welcome='Welcome',
    SignUp='SignUp'



}