import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import SplashScreen from '../Screen/Auth/SplashScreen'
import Onboarding from '../Screen/Auth/Onboarding'

const AuthStackNavigator = () => {
  return (

    <Onboarding/>
 
  )
}

export default AuthStackNavigator

const styles = StyleSheet.create({})