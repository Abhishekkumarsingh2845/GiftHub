
import WalkthroughSvg from  '../images/walkthrough.svg'
 export const Images={

    onboarding:require('../images/onboarding.png'),
    startedlogo:require('../images/StartedLogo.png'),
    squareBackground:require('../images/SquareBackground.png'),
    backgroudShadow:require('../images/BackgroundShadow.svg'),
 walkthrough: WalkthroughSvg,
 bigGift:require('../../assets/images/biggift.png')
}
 


